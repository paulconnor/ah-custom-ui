(function (window) {
    window.__env = window.__env || {};

    // Host url to connect to
    window.__env.baseServiceUrl = 'https://auth.broadcom.com/default/';
    //window.__env.baseServiceUrl = '';
    //Client id of connecting application
    window.__env.clientId = '95d95d9c-81f9-4094-9656-d84e24817e1b';
    //client secret
    window.__env.clientSecret = 'c3f6e243-f1cd-4289-8112-03b77b3367f4';
    window.__env.logoutUrl = '';

}(this));
