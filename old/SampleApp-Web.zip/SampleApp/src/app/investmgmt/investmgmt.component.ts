import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-investmgmt',
  templateUrl: './investmgmt.component.html',
  styleUrls: ['./investmgmt.component.css']
})
export class InvestmgmtComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
