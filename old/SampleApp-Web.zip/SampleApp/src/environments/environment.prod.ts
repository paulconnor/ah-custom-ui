export const environment = {
  production: true,
  development: false,
  apiUrl: '/default/'
};
